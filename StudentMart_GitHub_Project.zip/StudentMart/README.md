# StudentMart

A beginner-friendly Java Servlet + JDBC shopping application for the capstone project.

## Features
- Buyer and Seller registration
- BCrypt password hashing
- Login/logout with HttpSession
- Protected seller pages
- Seller product create/delete
- Buyer product browsing and keyword/category search
- Shopping cart with quantity update/remove
- Mock checkout
- Orders and order items stored in MySQL
- PreparedStatement for SQL
- Controller → Service → DAO structure

## Stack
Java 17, Maven, Tomcat 9.x, MySQL, JSP/Servlets, JDBC, BCrypt.

## Quick start
1. Create a MySQL database using `schema.sql`.
2. Edit `DBConnection.java` with your MySQL username/password.
3. Run `mvn clean package`.
4. Deploy `target/studentmart.war` to Tomcat 9.
5. Open `http://localhost:8080/studentmart/`.

## Demo journey
Register as SELLER → Login → Add product → Logout → Register/login as BUYER → Search → Add to cart → Checkout → View order confirmation.

## Important
This is a student capstone MVP. The checkout uses a mock payment confirmation; no real payment gateway is connected.
