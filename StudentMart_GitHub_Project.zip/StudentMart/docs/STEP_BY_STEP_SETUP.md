# StudentMart — Step-by-Step Setup

## 1. Install
Install Java 17, MySQL, Maven and Apache Tomcat 9.x.

## 2. Create the database
Open MySQL Workbench and run the complete `schema.sql` file.

## 3. Set the database password
Open:
`src/main/java/com/studentmart/util/DBConnection.java`

Change:
`YOUR_MYSQL_PASSWORD`

to your MySQL password.

## 4. Open the project
Open the `StudentMart` folder in VS Code or IntelliJ IDEA.

## 5. Build
In the terminal:
```bash
mvn clean package
```

The WAR file will be:
`target/studentmart.war`

## 6. Run on Tomcat
Copy `target/studentmart.war` into Tomcat's `webapps` folder and start Tomcat.

Open:
`http://localhost:8080/studentmart/`

## 7. Test the full journey
### Seller
1. Register as Seller.
2. Login.
3. Open Seller Dashboard.
4. Add a product.
5. Confirm it appears in the product list.

### Buyer
1. Logout.
2. Register as Buyer.
3. Login.
4. Search for the seller's product.
5. Add it to cart.
6. Update quantity.
7. Checkout.
8. Confirm the order ID.

## 8. GitHub upload
Create an empty GitHub repository named `studentmart`.

Then:
```bash
git init
git add .
git commit -m "feat: create StudentMart MVP"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

For the weekly requirement, continue with small commits:
```bash
git add .
git commit -m "feat: improve product search"
git push
```

## 9. Before submission
- Confirm GitHub contains source code, README and schema.
- Confirm `mvn clean package` succeeds.
- Do not upload passwords.
- Do not upload the `target` folder.
- Add screenshots of login, seller dashboard, products, cart and checkout if your faculty asks for them.
