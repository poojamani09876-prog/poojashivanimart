# StudentMart — Project Documentation

## 1. Introduction
StudentMart is a web-based shopping application developed with Java Servlets, JSP, JDBC and MySQL. It demonstrates authentication, seller product management, buyer shopping, cart management and a mock checkout.

## 2. Users
### Buyer
- Register and login
- Browse products
- Search by keyword/category
- Add products to cart
- Update/remove cart items
- Complete mock checkout

### Seller
- Register and login
- Open seller dashboard
- Add product listings
- Delete own products

## 3. Architecture
Browser → Servlet/Controller → Service → DAO → MySQL

The DAO layer contains SQL. Services contain validation/business rules. Controllers handle HTTP requests.

## 4. Security
- BCrypt password hashing
- PreparedStatement
- HttpSession authentication
- Protected seller/cart/checkout routes
- HTTP-only session cookie
- No plaintext passwords in the database

## 5. Database
Tables:
- users
- products
- cart_items
- orders
- order_items

Money uses DECIMAL(10,2). Foreign keys maintain relationships.

## 6. Main user journey
Register → Login → Browse → Search → Add to Cart → Update Cart → Mock Checkout → Order Confirmation

## 7. Definition of Done for MVP
- Project builds with Maven.
- Database schema executes successfully.
- Registration and login work.
- Passwords are BCrypt hashed.
- Seller can add/delete products.
- Buyer can search and add products.
- Cart supports update/remove.
- Checkout creates an order.
- GitHub repository contains the project.
- README explains how to run it.

## 8. Future Improvements
- Product editing
- Buyer order history
- Seller order management
- Product image upload
- Real payment gateway
- Connection pooling
- Better validation and error pages
- Automated integration tests
