package com.studentmart.service;

import com.studentmart.dao.OrderDAO;
import com.studentmart.model.CartItem;
import java.util.List;

public class OrderService {
    private final OrderDAO dao = new OrderDAO();
    public int checkout(int userId, List<CartItem> items) { return dao.createOrder(userId, items); }
}
