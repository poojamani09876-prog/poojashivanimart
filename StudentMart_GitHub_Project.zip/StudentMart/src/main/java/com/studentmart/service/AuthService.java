package com.studentmart.service;

import com.studentmart.dao.UserDAO;
import com.studentmart.model.User;
import org.mindrot.jbcrypt.BCrypt;

public class AuthService {
    private final UserDAO dao = new UserDAO();

    public String register(String name, String email, String password, String role) {
        name = name == null ? "" : name.trim();
        email = email == null ? "" : email.trim().toLowerCase();
        password = password == null ? "" : password;

        if (name.isBlank() || email.isBlank() || password.length() < 6)
            return "Name, email and a password of at least 6 characters are required.";
        if (!email.contains("@"))
            return "Please enter a valid email.";
        if (!role.equals("BUYER") && !role.equals("SELLER"))
            return "Invalid role.";
        if (dao.existsByEmail(email))
            return "This email is already registered.";

        String hash = BCrypt.hashpw(password, BCrypt.gensalt(12));
        return dao.register(new User(name,email,hash,role))
                ? null : "Registration failed.";
    }

    public User login(String email, String password) {
        if (email == null || password == null) return null;
        User u = dao.findByEmail(email.trim().toLowerCase());
        return u != null && BCrypt.checkpw(password, u.getPassword()) ? u : null;
    }
}
