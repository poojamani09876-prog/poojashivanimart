package com.studentmart.service;

import com.studentmart.dao.CartDAO;
import com.studentmart.dao.ProductDAO;
import com.studentmart.model.CartItem;
import com.studentmart.model.Product;
import java.util.List;

public class CartService {
    private final CartDAO cartDAO = new CartDAO();
    private final ProductDAO productDAO = new ProductDAO();

    public String add(int userId, int productId, int quantity) {
        if (quantity < 1) return "Quantity must be at least 1.";
        Product p = productDAO.findById(productId);
        if (p == null) return "Product not found.";
        if (p.getStockQty() < quantity) return "Not enough stock available.";
        cartDAO.add(userId, productId, quantity);
        return null;
    }

    public List<CartItem> list(int userId) { return cartDAO.findByUser(userId); }
    public void update(int userId, int productId, int qty) {
        if (qty <= 0) cartDAO.remove(userId, productId);
        else cartDAO.update(userId, productId, qty);
    }
    public void remove(int userId, int productId) { cartDAO.remove(userId, productId); }
    public void clear(int userId) { cartDAO.clear(userId); }
}
