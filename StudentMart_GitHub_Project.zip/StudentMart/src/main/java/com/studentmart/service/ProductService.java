package com.studentmart.service;

import com.studentmart.dao.ProductDAO;
import com.studentmart.model.Product;
import java.math.BigDecimal;
import java.util.List;

public class ProductService {
    private final ProductDAO dao = new ProductDAO();

    public String create(int sellerId, String name, String description, String priceText,
                         String stockText, String category, String imageUrl) {
        try {
            name = name == null ? "" : name.trim();
            category = category == null ? "" : category.trim();
            if (name.isBlank() || category.isBlank()) return "Name and category are required.";
            BigDecimal price = new BigDecimal(priceText);
            int stock = Integer.parseInt(stockText);
            if (price.compareTo(BigDecimal.ZERO) <= 0) return "Price must be greater than 0.";
            if (stock < 0) return "Stock cannot be negative.";

            Product p = new Product();
            p.setSellerId(sellerId); p.setName(name); p.setDescription(description);
            p.setPrice(price); p.setStockQty(stock); p.setCategory(category); p.setImageUrl(imageUrl);
            return dao.create(p) ? null : "Could not create product.";
        } catch (Exception e) {
            return "Enter a valid price and stock quantity.";
        }
    }

    public List<Product> search(String keyword, String category) {
        return dao.search(keyword == null ? "" : keyword.trim(),
                          category == null ? "" : category.trim());
    }

    public List<Product> sellerProducts(int sellerId) { return dao.findBySeller(sellerId); }
    public Product find(int id) { return dao.findById(id); }
    public boolean delete(int id, int sellerId) { return dao.delete(id, sellerId); }
}
