package com.studentmart.filter;

import com.studentmart.model.User;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.*;
import java.io.IOException;

@WebFilter(urlPatterns = {"/seller/*", "/cart", "/cart/*", "/checkout"})
public class AuthFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        User user = (User) req.getSession(false).getAttribute("user");
        if (user == null) {
            res.sendRedirect(req.getContextPath() + "/login.jsp?error=login");
            return;
        }
        String uri = req.getRequestURI();
        if (uri.contains("/seller/") && !"SELLER".equals(user.getRole())) {
            res.sendError(HttpServletResponse.SC_FORBIDDEN, "Seller access required.");
            return;
        }
        chain.doFilter(request, response);
    }
}
