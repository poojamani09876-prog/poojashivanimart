package com.studentmart.dao;

import com.studentmart.model.CartItem;
import com.studentmart.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartDAO {
    public void add(int userId, int productId, int quantity) {
        String sql = "INSERT INTO cart_items(user_id,product_id,quantity) VALUES(?,?,?) " +
                     "ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1,userId); ps.setInt(2,productId); ps.setInt(3,quantity);
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException("Could not add to cart", e); }
    }

    public List<CartItem> findByUser(int userId) {
        List<CartItem> list = new ArrayList<>();
        String sql = "SELECT c.product_id,p.name,p.price,c.quantity,p.stock_qty " +
                     "FROM cart_items c JOIN products p ON c.product_id=p.id WHERE c.user_id=? ORDER BY c.id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1,userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    CartItem item = new CartItem();
                    item.setProductId(rs.getInt("product_id"));
                    item.setProductName(rs.getString("name"));
                    item.setPrice(rs.getBigDecimal("price"));
                    item.setQuantity(rs.getInt("quantity"));
                    item.setStockQty(rs.getInt("stock_qty"));
                    list.add(item);
                }
            }
            return list;
        } catch (SQLException e) { throw new RuntimeException("Could not load cart", e); }
    }

    public void update(int userId, int productId, int quantity) {
        String sql = "UPDATE cart_items SET quantity=? WHERE user_id=? AND product_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1,quantity); ps.setInt(2,userId); ps.setInt(3,productId);
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException("Could not update cart", e); }
    }

    public void remove(int userId, int productId) {
        String sql = "DELETE FROM cart_items WHERE user_id=? AND product_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1,userId); ps.setInt(2,productId);
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException("Could not remove cart item", e); }
    }

    public void clear(int userId) {
        String sql = "DELETE FROM cart_items WHERE user_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1,userId); ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException("Could not clear cart", e); }
    }
}
