package com.studentmart.dao;

import com.studentmart.model.CartItem;
import com.studentmart.util.DBConnection;
import java.sql.*;
import java.math.BigDecimal;
import java.util.List;

public class OrderDAO {
    public int createOrder(int userId, List<CartItem> items) {
        if (items.isEmpty()) throw new IllegalArgumentException("Cart is empty");

        String orderSql = "INSERT INTO orders(user_id,total_amount,status) VALUES(?,?,?)";
        String itemSql = "INSERT INTO order_items(order_id,product_id,quantity,price) VALUES(?,?,?,?)";
        String stockSql = "UPDATE products SET stock_qty=stock_qty-? WHERE id=? AND stock_qty>=?";
        BigDecimal total = BigDecimal.ZERO;
        for (CartItem item : items) total = total.add(item.getLineTotal());

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                for (CartItem item : items) {
                    if (item.getQuantity() > item.getStockQty())
                        throw new IllegalArgumentException("Not enough stock for " + item.getProductName());
                }

                int orderId;
                try (PreparedStatement ps = con.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1,userId); ps.setBigDecimal(2,total); ps.setString(3,"PLACED");
                    ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (!rs.next()) throw new SQLException("No order id generated");
                        orderId = rs.getInt(1);
                    }
                }

                try (PreparedStatement itemPs = con.prepareStatement(itemSql);
                     PreparedStatement stockPs = con.prepareStatement(stockSql)) {
                    for (CartItem item : items) {
                        itemPs.setInt(1,orderId); itemPs.setInt(2,item.getProductId());
                        itemPs.setInt(3,item.getQuantity()); itemPs.setBigDecimal(4,item.getPrice());
                        itemPs.addBatch();

                        stockPs.setInt(1,item.getQuantity()); stockPs.setInt(2,item.getProductId()); stockPs.setInt(3,item.getQuantity());
                        stockPs.addBatch();
                    }
                    itemPs.executeBatch();
                    int[] stockResults = stockPs.executeBatch();
                    for (int r : stockResults) if (r != 1) throw new SQLException("Stock changed. Please try again.");
                }

                con.commit();
                return orderId;
            } catch (Exception e) {
                con.rollback();
                if (e instanceof IllegalArgumentException iae) throw iae;
                throw e;
            } finally {
                con.setAutoCommit(true);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Checkout failed", e);
        }
    }
}
