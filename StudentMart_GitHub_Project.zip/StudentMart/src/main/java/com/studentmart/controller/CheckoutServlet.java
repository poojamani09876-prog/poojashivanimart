package com.studentmart.controller;

import com.studentmart.model.User;
import com.studentmart.service.CartService;
import com.studentmart.service.OrderService;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {
    private final CartService cartService = new CartService();
    private final OrderService orderService = new OrderService();

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User u = (User) req.getSession(false).getAttribute("user");
        try {
            var items = cartService.list(u.getId());
            int orderId = orderService.checkout(u.getId(), items);
            cartService.clear(u.getId());
            res.sendRedirect(req.getContextPath() + "/success.jsp?orderId=" + orderId);
        } catch (Exception e) {
            res.sendRedirect(req.getContextPath() + "/cart?error=" +
                    java.net.URLEncoder.encode(e.getMessage(), "UTF-8"));
        }
    }
}
