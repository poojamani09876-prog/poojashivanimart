package com.studentmart.controller;

import com.studentmart.model.User;
import com.studentmart.service.AuthService;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private final AuthService service = new AuthService();

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = service.login(req.getParameter("email"), req.getParameter("password"));
        if (user == null) {
            res.sendRedirect(req.getContextPath() + "/login.jsp?error=1");
            return;
        }
        HttpSession old = req.getSession(false);
        if (old != null) old.invalidate();
        HttpSession session = req.getSession(true);
        session.setAttribute("user", user);
        session.setMaxInactiveInterval(30 * 60);
        res.sendRedirect(req.getContextPath() + "/products");
    }
}
