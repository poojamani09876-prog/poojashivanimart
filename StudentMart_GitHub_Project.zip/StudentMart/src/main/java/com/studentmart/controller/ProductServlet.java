package com.studentmart.controller;

import com.studentmart.service.ProductService;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/products")
public class ProductServlet extends HttpServlet {
    private final ProductService service = new ProductService();

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.setAttribute("products", service.search(req.getParameter("q"), req.getParameter("category")));
        RequestDispatcher rd = req.getRequestDispatcher("/products.jsp");
        rd.forward(req, res);
    }
}
