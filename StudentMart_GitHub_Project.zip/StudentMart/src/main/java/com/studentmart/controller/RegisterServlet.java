package com.studentmart.controller;

import com.studentmart.service.AuthService;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private final AuthService service = new AuthService();

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String error = service.register(req.getParameter("name"), req.getParameter("email"),
                req.getParameter("password"), req.getParameter("role"));
        if (error == null) res.sendRedirect(req.getContextPath() + "/login.jsp?registered=1");
        else res.sendRedirect(req.getContextPath() + "/register.jsp?error=" + java.net.URLEncoder.encode(error, "UTF-8"));
    }
}
