package com.studentmart.controller;

import com.studentmart.model.User;
import com.studentmart.service.ProductService;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/seller/products")
public class SellerServlet extends HttpServlet {
    private final ProductService service = new ProductService();

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, javax.servlet.ServletException {
        User u = (User) req.getSession(false).getAttribute("user");
        req.setAttribute("products", service.sellerProducts(u.getId()));
        req.getRequestDispatcher("/seller.jsp").forward(req, res);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User u = (User) req.getSession(false).getAttribute("user");
        String action = req.getParameter("action");
        if ("delete".equals(action)) {
            service.delete(Integer.parseInt(req.getParameter("id")), u.getId());
        } else {
            String error = service.create(u.getId(), req.getParameter("name"), req.getParameter("description"),
                    req.getParameter("price"), req.getParameter("stock"), req.getParameter("category"),
                    req.getParameter("imageUrl"));
            if (error != null) {
                res.sendRedirect(req.getContextPath() + "/seller/products?error=" +
                        java.net.URLEncoder.encode(error, "UTF-8"));
                return;
            }
        }
        res.sendRedirect(req.getContextPath() + "/seller/products");
    }
}
