package com.studentmart.controller;

import com.studentmart.model.User;
import com.studentmart.service.CartService;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {
    private final CartService service = new CartService();

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, javax.servlet.ServletException {
        User u = (User) req.getSession(false).getAttribute("user");
        req.setAttribute("items", service.list(u.getId()));
        req.getRequestDispatcher("/cart.jsp").forward(req, res);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User u = (User) req.getSession(false).getAttribute("user");
        String action = req.getParameter("action");
        int productId = Integer.parseInt(req.getParameter("productId"));
        if ("add".equals(action)) {
            String error = service.add(u.getId(), productId, Integer.parseInt(req.getParameter("quantity")));
            if (error != null) {
                res.sendRedirect(req.getContextPath() + "/products?error=" +
                        java.net.URLEncoder.encode(error, "UTF-8"));
                return;
            }
        } else if ("update".equals(action)) {
            service.update(u.getId(), productId, Integer.parseInt(req.getParameter("quantity")));
        } else if ("remove".equals(action)) {
            service.remove(u.getId(), productId);
        }
        res.sendRedirect(req.getContextPath() + "/cart");
    }
}
