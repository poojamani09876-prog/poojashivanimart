<%@ page import="java.util.List,com.studentmart.model.Product,com.studentmart.model.User" %>
<!DOCTYPE html><html><head><title>Seller Dashboard</title><link rel="stylesheet" href="../style.css"></head><body>
<nav><b>🛍️ StudentMart</b><span><a href="../products">Shop</a> | <a href="../logout">Logout</a></span></nav>
<div class="container">
<h1>Seller Dashboard</h1><p class="muted">Add simple, clear product listings for buyers.</p>
<% if(request.getParameter("error")!=null){ %><div class="error"><%=request.getParameter("error")%></div><% } %>
<div class="panel"><h2>Add Product</h2>
<form action="products" method="post">
<input type="hidden" name="action" value="create">
<label>Product name</label><input name="name" required>
<label>Description</label><textarea name="description" rows="3"></textarea>
<label>Price (₹)</label><input type="number" name="price" min="0.01" step="0.01" required>
<label>Stock quantity</label><input type="number" name="stock" min="0" required>
<label>Category</label><input name="category" placeholder="Books, Electronics..." required>
<label>Image URL (optional)</label><input name="imageUrl">
<button>Add product</button>
</form></div>
<h2>Your Products</h2>
<div class="grid">
<% List<Product> products=(List<Product>)request.getAttribute("products"); for(Product p:products){ %>
<div class="card"><h3><%=p.getName()%></h3><p><%=p.getDescription()%></p><b>₹<%=p.getPrice()%></b><p>Stock: <%=p.getStockQty()%></p>
<form action="products" method="post"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<%=p.getId()%>"><button class="danger">Delete</button></form></div>
<% } %></div></div></body></html>
