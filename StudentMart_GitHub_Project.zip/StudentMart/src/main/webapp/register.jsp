<!DOCTYPE html>
<html><head><title>StudentMart - Register</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container small">
<h1>🛍️ StudentMart</h1><h2>Create your account</h2>
<% if (request.getParameter("error") != null) { %><div class="error"><%= request.getParameter("error") %></div><% } %>
<form action="register" method="post">
<label>Full name</label><input type="text" name="name" required>
<label>Email</label><input type="email" name="email" required>
<label>Password <span class="muted">(minimum 6 characters)</span></label><input type="password" name="password" minlength="6" required>
<label>I am a</label>
<select name="role"><option value="BUYER">Buyer</option><option value="SELLER">Seller</option></select>
<button>Create account</button>
</form>
<p>Already registered? <a href="login.jsp">Login</a></p>
</div>
</body></html>
