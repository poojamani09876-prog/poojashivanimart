<!DOCTYPE html>
<html><head><title>StudentMart - Login</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container small">
<h1>🛍️ StudentMart</h1><h2>Welcome back</h2>
<p class="muted">Login to browse products or manage your shop.</p>
<% if ("1".equals(request.getParameter("error"))) { %><div class="error">Invalid email or password.</div><% } %>
<% if ("1".equals(request.getParameter("registered"))) { %><div class="success">Account created. Please login.</div><% } %>
<form action="login" method="post">
<label>Email</label><input type="email" name="email" required>
<label>Password</label><input type="password" name="password" required>
<button>Login</button>
</form>
<p>New here? <a href="register.jsp">Create an account</a></p>
</div>
</body></html>
