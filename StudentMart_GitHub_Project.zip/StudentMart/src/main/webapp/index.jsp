<!DOCTYPE html>
<html>
<head><title>StudentMart</title><meta http-equiv="refresh" content="0;url=products"></head>
<body>Opening StudentMart...</body>
</html>
