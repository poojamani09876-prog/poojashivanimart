<!DOCTYPE html><html><head><title>Order Confirmed</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container small center"><div class="success big">✓</div><h1>Order placed!</h1><p>Your mock payment was confirmed successfully.</p><p><b>Order ID:</b> #<%=request.getParameter("orderId")%></p><a class="button" href="products">Continue shopping</a></div></body></html>
