<%@ page import="java.util.List,java.math.BigDecimal,com.studentmart.model.CartItem" %>
<!DOCTYPE html><html><head><title>Your Cart</title><link rel="stylesheet" href="style.css"></head><body>
<nav><b>🛍️ StudentMart</b><span><a href="products">Continue shopping</a> | <a href="logout">Logout</a></span></nav>
<div class="container"><h1>Your Cart</h1>
<% if(request.getParameter("error")!=null){ %><div class="error"><%=request.getParameter("error")%></div><% } %>
<% List<CartItem> items=(List<CartItem>)request.getAttribute("items"); BigDecimal total=BigDecimal.ZERO;
if(items.isEmpty()){ %><div class="panel"><h2>Your cart is empty 🛒</h2><a class="button" href="products">Browse products</a></div><% } else {
for(CartItem i:items){ total=total.add(i.getLineTotal()); %>
<div class="cartrow"><div><h3><%=i.getProductName()%></h3><p>₹<%=i.getPrice()%> each</p></div>
<form action="cart" method="post"><input type="hidden" name="action" value="update"><input type="hidden" name="productId" value="<%=i.getProductId()%>"><input class="qty" type="number" name="quantity" value="<%=i.getQuantity()%>" min="0" max="<%=i.getStockQty()%>"><button>Update</button></form>
<form action="cart" method="post"><input type="hidden" name="action" value="remove"><input type="hidden" name="productId" value="<%=i.getProductId()%>"><button class="danger">Remove</button></form>
<strong>₹<%=i.getLineTotal()%></strong></div>
<% } %>
<div class="total"><h2>Total: ₹<%=total%></h2><form action="checkout" method="post"><button>Checkout (Mock Payment)</button></form></div>
<% } %></div></body></html>
