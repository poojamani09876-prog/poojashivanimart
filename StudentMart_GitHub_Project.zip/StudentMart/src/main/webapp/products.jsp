<%@ page import="java.util.List,com.studentmart.model.Product,com.studentmart.model.User" %>
<!DOCTYPE html><html><head><title>StudentMart - Products</title><link rel="stylesheet" href="style.css"></head><body>
<nav><b>🛍️ StudentMart</b><span><a href="products">Shop</a> | <a href="cart">Cart</a>
<% User user=(User)session.getAttribute("user"); if(user!=null){ %>
 | Hello, <%=user.getName()%> | <a href="logout">Logout</a>
<% if("SELLER".equals(user.getRole())) { %> | <a href="seller/products">Seller Dashboard</a><% } } else { %>
 | <a href="login.jsp">Login</a> | <a href="register.jsp">Register</a><% } %></span></nav>
<div class="container">
<h1>Find something you like</h1>
<form class="search" action="products" method="get">
<input name="q" placeholder="Search products..." value="<%=request.getParameter("q")==null?"":request.getParameter("q")%>">
<input name="category" placeholder="Category" value="<%=request.getParameter("category")==null?"":request.getParameter("category")%>">
<button>Search</button>
</form>
<% if(request.getParameter("error")!=null){ %><div class="error"><%=request.getParameter("error")%></div><% } %>
<div class="grid">
<% List<Product> products=(List<Product>)request.getAttribute("products");
for(Product p:products){ %>
<div class="card">
<% if(p.getImageUrl()!=null && !p.getImageUrl().isBlank()){ %><img src="<%=p.getImageUrl()%>" alt="Product"><% } else { %><div class="emoji">📦</div><% } %>
<h3><%=p.getName()%></h3><p><%=p.getDescription()==null?"":p.getDescription()%></p>
<span class="tag"><%=p.getCategory()%></span><h2>₹<%=p.getPrice()%></h2>
<p class="muted">Stock: <%=p.getStockQty()%></p>
<% if(user!=null && "BUYER".equals(user.getRole()) && p.getStockQty()>0){ %>
<form action="cart" method="post"><input type="hidden" name="action" value="add"><input type="hidden" name="productId" value="<%=p.getId()%>">
<input class="qty" type="number" name="quantity" value="1" min="1" max="<%=p.getStockQty()%>"><button>Add to cart</button></form>
<% } else if(p.getStockQty()==0){ %><button disabled>Out of stock</button><% } %>
</div>
<% } %>
</div></div></body></html>
